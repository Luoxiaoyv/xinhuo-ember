'use strict';
/* ══════════════════════════════════════════════
   心火 EMBER · 自动化测试
   运行：node test/test.js   （或 npm test）
   无需任何构建步骤 —— 脚本会自己从 index.html 里
   抽出内联 JS 来跑，clone 下来即可运行。
   ══════════════════════════════════════════════ */
const fs=require('fs');
const path=require('path');
const ROOT=path.join(__dirname,'..');
const RAW_HTML=fs.readFileSync(path.join(ROOT,'index.html'),'utf8');
// 从 index.html 自动提取内联脚本
const code=(()=>{
  const m=RAW_HTML.match(/<script>([\s\S]*?)<\/script>/);
  if(!m)throw new Error('在 index.html 中找不到 <script> 块');
  return m[1];
})();

function mkEl(tag='div'){
  const e={
    tag,_children:[],_attrs:{},_cls:new Set(),
    style:{setProperty(){}},
    offsetWidth:0,offsetHeight:0,
    getBoundingClientRect(){return{left:20,top:40,width:200,height:50};},
    get dataset(){
      const self=this;
      return new Proxy({},{
        get:(t,k)=>self._attrs['data-'+k],
        set:(t,k,v)=>{self._attrs['data-'+k]=v;return true;}
      });
    },
    _ls:{},disabled:false,value:'',innerHTML:'',textContent:'',
    focus(){},select(){},
    setAttribute(k,v){this._attrs[k]=v},
    removeAttribute(k){delete this._attrs[k]},
    getAttribute(k){return this._attrs[k]?this._attrs[k]:null},
    appendChild(c){this._children.push(c);c._parent=this},
    addEventListener(t,f){this._ls[t]=f},
    scrollIntoView(){},
    closest(sel){return matchSel(this,sel)?this:(this._parent?this._parent.closest(sel):null)},
    classList:{
      add:(...c)=>c.forEach(x=>e._cls.add(x)),
      remove:(...c)=>c.forEach(x=>e._cls.delete(x)),
      toggle:(c,force)=>{if(force===true)e._cls.add(c);else if(force===false)e._cls.delete(c);else if(e._cls.has(c))e._cls.delete(c);else e._cls.add(c)},
      contains:c=>e._cls.has(c)
    },
    querySelectorAll(sel){
      const out=[];const walk=n=>n._children.forEach(c=>{if(matchSel(c,sel))out.push(c);walk(c);});walk(this);return out;
    },
    querySelector(sel){return this.querySelectorAll(sel)[0]||null;},
    click(){this._ls.click&&this._ls.click();}
  };
  return e;
}
function matchSel(el, sel){
  const m=sel.match(/^(\w+)((?:\.\w+|\[[\w-]+=[\w-]+\])*)$/);
  if(!m)return false;
  if(m[1]!==el.tag)return false;
  const parts=m[2].match(/\.\w+|\[[\w-]+=[\w-]+\]/g)||[];
  for(const p of parts){
    if(p.startsWith('.')){if(!el._cls.has(p.slice(1)))return false;}
    else{const [k,v]=p.slice(1,-1).split('=');if(el._attrs[k]!==v)return false;}
  }
  return true;
}
const els={};
global.document={
  getElementById:id=>els[id]||(els[id]=mkEl('div')),
  querySelector:(sel)=>{
    // 优先找 scr-* 容器
    for(const id in els){
      if(id.startsWith('scr-')){
        const e=els[id];
        if(e.tag==='section'&&matchSel(e,sel))return e;
        const sub=e.querySelector(sel);
        if(sub)return sub;
      }
    }
    return null;
  },
  querySelectorAll:()=>[],
  createElement:(tag)=>mkEl(tag||'div'),
  createElementNS:()=>mkEl('el'),
  documentElement:mkEl('html')
};
global.localStorage={_s:null,getItem(){return this._s;},setItem(k,v){this._s=v;},removeItem(){this._s=null;}};
global.requestAnimationFrame=f=>f();
const realSetTimeout=setTimeout;
global.setTimeout=f=>{f();return 0;}; // 同步化所有延时
global.clearTimeout=()=>{};
global.cancelAnimationFrame=()=>{};
global.window={
  addEventListener(){},
  removeEventListener(){},
  requestAnimationFrame:cb=>setTimeout(cb,0),
  cancelAnimationFrame(){},
  innerWidth:420,innerHeight:800
};

let failed=0;
const ok=(cond,msg)=>{console.log((cond?'  PASS ':'  FAIL ')+'- '+msg);if(!cond)failed++;};

eval(code+`
;Object.assign(globalThis,{
  completeTask, viewReport, save, load, flameScale, checkTitles, endDay, renderAll,
  showTutorial, advanceTutorial, endTutorial, hideGuide, showTabbar, TUT,
  applyGuideLayout, bindGuideScroll, unbindGuideScroll, positionGuide,
  showTutorialStep,
  seedDemoTasks, demoRoll, openCustomDemo, closeCustomDemo, acceptPending
});
// 用 defineProperty 暴露可变状态（Object.assign 会把 getter 拍平成一次性快照）
Object.defineProperty(globalThis,'S',{get:()=>S,set:v=>{S=v},configurable:true});
Object.defineProperty(globalThis,'pendingTask',{get:()=>pendingTask,set:v=>{pendingTask=v},configurable:true});
`);

// 为自拟签弹层预建 DOM
els['custom-cat']=mkEl('div');
['grow','habit','fate'].forEach(c=>{
  const b=mkEl('button');b._attrs['data-c']=c;if(c==='grow')b._cls.add('on');
  els['custom-cat'].appendChild(b);
});
els['custom-n']=els['custom-n']||mkEl('input');
els['custom-d']=els['custom-d']||mkEl('textarea');

// 预建引导相关元素
['guide-mask','guide-spot','guide-tip','gt-step','gt-t','gt-dots','gt-btn','gt-skip',
 'welcome-go','welcome-skip','btn-retutor','btn-reset','ob-name','ob-go','ob-intns','tabbar',
 'btn-roll','btn-accept','btn-night','btn-next','btn-custom','custom-ok','modal-custom',
 'reveal-zone','reveal-actions','dice-stage','altar-stage','task-list','card3d','card-back','dice'].forEach(id=>{
  if(!els[id])els[id]=mkEl('input');
});
els['gt-btn']._attrs={};els['gt-skip']._attrs={};els['welcome-go']._attrs={};

// ──────────────────────────────────────────────
// 引导流程（独立运行，先清空持久化）
// ──────────────────────────────────────────────
console.log('=== 引导流程 ===');
S.tutorialDone=false;S.tutorialStep=0;S.onboarded=false;S.name='';S.intentions=[];S.tasks=[];S.cycle=1;S.day=1;
S.cycleStats={done:0,rolled:0,byCat:{grow:0,habit:0,fate:0},streak:0,maxStreak:0,doneToday:0,daysLit:[]};
S.history=[];S.imprints=[];S.titles=[];S.cyclesCompleted=0;S.pendingReport=null;S.customPool=[];
els['tabbar'].style.display='none';

// 模拟启动：未点过火 → 切到欢迎屏
showTutorial();
ok(S.tutorialStep===0,'欢迎屏为起点');
ok(els['tabbar'].style.display!=='flex','欢迎屏不显示导航栏');

console.log('--- A. 走完引导全流程（8 步） ---');
els['welcome-go'].click();   // 第 1 步
ok(S.tutorialStep===1,'welcome-go → 第 1 步');
ok(S.onboarded===false,'尚未点火');
els['ob-name'].value='guider';
els['ob-go'].click();         // 点火，自动推进到第 2 步
ok(S.onboarded===true,'点火完成');
ok(S.tutorialStep===2,'点火后自动推进到第 2 步（主屏：火）');
ok(S.tasks.length===2,'第 2 步已预置 2 张演示任务明细，界面不会空着');
ok(els['tabbar'].style.display==='flex','主屏显示导航栏');

console.log('--- A2. 第 4 步：自动演示掷骰 ---');
els['gt-btn'].click();        // → 步 3
ok(S.tutorialStep===3,'到第 3 步（任务明细）');
els['gt-btn'].click();        // → 步 4，run 自动掷骰
ok(S.tutorialStep===4,'到第 4 步（掷）');
ok(!!pendingTask,'自动掷骰后 pendingTask 已生成（用户能看到翻卡）');

console.log('--- A3. 第 6 步：自动打开自拟输入框 ---');
els['gt-btn'].click();        // → 步 5
ok(S.tutorialStep===5,'到第 5 步（签来了）');
els['gt-btn'].click();        // → 步 6，run 打开自拟模态
ok(S.tutorialStep===6,'到第 6 步（自拟）');
ok(els['modal-custom'].classList.contains('show'),'自拟弹层已打开，文本框可见');
ok(els['custom-n'].value.length>0,'自拟输入框已预填当前签名');
ok(els['custom-d'].value!==undefined,'描述文本框存在');

console.log('--- A4. 第 7 步：自动接签，任务明细出现 ---');
els['gt-btn'].click();        // → 步 7，exit 关模态 + run 接签
ok(S.tutorialStep===7,'到第 7 步（烧签）');
ok(!els['modal-custom'].classList.contains('show'),'自拟弹层已自动关闭');
ok(S.tasks.length===3,'已自动接下一签，任务明细 3 张');

console.log('--- A5. 第 8 步 → 关闭 ---');
els['gt-btn'].click();        // → 步 8
ok(S.tutorialStep===8,'到第 8 步（入夜）');
els['gt-btn'].click();        // → 溢出 → 关闭
ok(S.tutorialDone===true,'第 8 步后"知道了"→ 引导关闭');
ok(S.tutorialStep===0,'tutorialStep 归零');
ok(els['tabbar'].style.display==='flex','关闭后导航栏仍可见');

console.log('--- B. 跳过路径 ---');
S.tutorialDone=false;S.tutorialStep=0;S.onboarded=false;
showTutorial();
els['welcome-skip'].click();
ok(S.tutorialDone===true,'welcome-skip → tutorialDone');
ok(S.onboarded===false,'welcome-skip 不强制点火');

console.log('--- C. 引导中"跳过引导"按钮 ---');
S.tutorialDone=false;S.tutorialStep=6;S.onboarded=true;S.name='g';S.intentions=['read'];
openCustomDemo();
els['gt-skip'].click();
ok(S.tutorialDone===true,'引导中点跳过 → tutorialDone=true');
ok(!els['modal-custom'].classList.contains('show'),'跳过后自拟弹层被关掉');

console.log('--- D. 设里"重看引导" ---');
S.tutorialDone=true;S.tutorialStep=0;S.onboarded=true;S.name='g';S.intentions=['read'];
els['btn-retutor'].click();
ok(S.tutorialDone===false,'重看 → tutorialDone=false');
ok(S.tutorialStep===1,'重看从第 1 步开始（完整走一遍，不再吃掉留名那步）');

console.log('--- E. 持久化 ---');
S.tutorialDone=true;S.tutorialStep=4;save();
const snap=JSON.parse(localStorage._s);
ok(snap.tutorialStep===4,'localStorage 记录 tutorialStep=4');
ok(snap.tutorialDone===true,'localStorage 记录 tutorialDone=true');

console.log('--- F. 旧存档兼容与引导版本 ---');
ok(TUT.length===9,'TUT 共 8 步 + 欢迎屏占位');
// 旧存档：无 tutVer 字段、已点火
const oldSave={v:1,onboarded:true,name:'old',intentions:['read'],cycle:1,day:1,tasks:[],rerolledToday:false,
  cycleStats:{done:0,rolled:0,byCat:{grow:0,habit:0,fate:0},streak:0,maxStreak:0,doneToday:0,daysLit:[]},
  history:[],imprints:[],titles:[],cyclesCompleted:0,pendingReport:null,customPool:[]};
localStorage._s=JSON.stringify(oldSave);
load();
ok(S.tutVer===4,'旧存档被打上引导版本 v4');
ok(S.tutorialDone===false&&S.tutorialStep===1,'旧用户被安排重看引导，从第 1 步（留名）开始，一步不落');
// 新用户：tutVer 已是最新，不会被重复打扰
localStorage._s=null;
S=null;               // 模拟页面重载（真实环境里 let S 会重新初始化）
load();
ok(S.tutVer===4&&S.tutorialStep===0,'全新用户从欢迎屏开始，且不会被版本升级重置');

// ──────────────────────────────────────────────
// G. 清晰度：引导必须是"清晰演示"，不允许任何模糊
// ──────────────────────────────────────────────
console.log('--- G. 引导清晰度（无模糊 + 聚光挖洞） ---');
const html=RAW_HTML;
const cssRule=n=>{
  const i=html.indexOf('.'+n+'{');
  return i<0?'':html.slice(i,html.indexOf('}',i)+1);
};
const ruleMask=cssRule('guide-mask');
const ruleSpot=cssRule('guide-spot');
const ruleTip=cssRule('guide-tip');
const ruleModal=cssRule('modal');
ok(ruleMask.length>0&&!/blur/i.test(ruleMask),'guide-mask 无 blur（原来 1.5px 模糊是界面发虚的元凶）');
ok(!/backdrop-filter/i.test(ruleTip),'guide-tip 无 backdrop-filter，提示卡本身不模糊');
ok(!/blur/i.test(ruleModal),'modal（自拟弹层）无 blur，输入框清晰可见');
ok(/9999px/.test(ruleSpot),'guide-spot 用超大 box-shadow 挖洞压暗，框内 100% 原始清晰');
ok(!/transition:\s*all/i.test(ruleSpot),'guide-spot 过渡只作用于位置尺寸，不让遮罩厚度参与动画');
ok(/\.app\.guiding\s+\.tabbar/.test(html),'引导中导航栏抬到聚光层之上（z-index:74），保持清晰');
const gtTextRule=(()=>{const i=html.indexOf('.guide-tip .gt-t{');return i<0?'':html.slice(i,html.indexOf('}',i)+1);})();
ok(/#efe3cb/.test(gtTextRule),'提示卡正文用高对比色 #efe3cb（原 #d6c7ab 偏灰发虚）');
ok(/-webkit-font-smoothing:antialiased/.test(ruleTip),'提示卡开启字体抗锯齿锐化');

// 运行时：聚光时不得叠加遮罩（否则双重变暗）
const probe=mkEl('div');
probe.getBoundingClientRect=()=>({left:60,top:120,width:200,height:40,right:260,bottom:160});
const realQS=global.document.querySelector;
global.document.querySelector=sel=>(sel==='#g-probe'?probe:realQS(sel));
hideGuide();
positionGuide({sel:'#g-probe'});
ok(els['guide-spot'].style.display==='block','聚光框已显示');
ok(els['guide-mask'].style.display==='none','聚光时遮罩关闭 → 无双重压暗，高亮区完全清晰');
global.document.querySelector=realQS;
// 无锚点时回到居中提示卡（refactor 后不再有遮罩，纯 tip 居中）
hideGuide();
positionGuide({sel:'#not-exist-anywhere'});
ok(els['guide-spot'].style.display==='none','无锚点：spot 隐藏（不再触发遮罩分支）');
ok(els['guide-tip'].style.display==='block','无锚点：tip 居中显示');

// guiding class 生命周期
S.tutorialDone=false;S.tutorialStep=2;S.onboarded=true;S.name='g';S.intentions=['read'];
showTutorialStep();
ok(els['app'].classList.contains('guiding'),'引导进行中 → app.guiding 生效');
endTutorial();
ok(!els['app'].classList.contains('guiding'),'引导结束 → app.guiding 移除');

// ──────────────────────────────────────────────
// H. 第 1 步（留名 · 选火向）不再被跳过
// ──────────────────────────────────────────────
console.log('--- H. 第 1 步：留 名 · 选 火 向 ---');
S.onboarded=true;S.name='旧名字';S.intentions=['read','health'];
S.tutorialDone=false;S.tutorialStep=1;
hideGuide();
showTutorialStep();
ok(S.tutorialStep===1,'已点火的老用户也从第 1 步看起');
ok(els['gt-btn'].textContent==='知 道 了','老用户第 1 步按钮为「知道了」——不代劳点火，免得覆盖真名');
ok(els['ob-name'].value==='旧名字','当初留的名字已填回输入框');
ok(/第 1 步/.test(els['gt-t'].innerHTML),'第 1 步用回顾版文案（明确告诉他这就是第 1 步）');
ok(/第 一 步/.test(els['gt-step'].textContent),'步骤标题显示「第 一 步」');
els['gt-btn'].click();
ok(S.tutorialStep===2,'「知道了」正常推进到第 2 步');
ok(S.onboarded===true&&S.name==='旧名字','推进过程未触发点火、未覆盖用户资料');
S.onboarded=false;S.name='';S.tutorialStep=1;
showTutorialStep();
ok(els['gt-btn'].textContent==='点 火 · 进 入','未点火用户在第 1 步按钮为「点火 · 进入」');
ok(S.tutorialStep===1,'新用户仍停在第 1 步，等他亲手点火');

// ──────────────────────────────────────────────
// H.5 滚动跟随：用户上下滑动屏幕时，spot/tip 跟着目标走；目标滚出视口则退化居中
// ──────────────────────────────────────────────
console.log('--- H.5 滚动跟随（spot 锁定 target 当前位置） ---');
// 桩：document.querySelector('.screen.active') 应返回带 addEventListener 的元素
const fakeScreen={_ls:{},_style_od:'',
  addEventListener(t,f){this._ls[t]=f;this._style_od+='+'+t;},
  removeEventListener(t,f){this._ls[t]=null;},
  scrollTop:0};
const realQS2=global.document.querySelector;
global.document.querySelector=sel=>{
  if(sel==='.screen.active')return fakeScreen;
  return realQS2(sel);
};
// 给 .app 一个稳定的 bounding rect（anchored）
els['app'].getBoundingClientRect=()=>({left:0,top:0,width:420,height:800,right:420,bottom:800});

// 准备一个可见的目标元素
const realRect={left:60,top:120,width:200,height:40,right:260,bottom:160,bottom_:160};
const targetEl={
  getBoundingClientRect:()=>({...realRect,bottom:realRect.top+realRect.height}),
  scrollIntoView(){}
};
// 把 querySelector('#btn-roll') 替换为目标桩
const realQS3=global.document.querySelector;
global.document.querySelector=sel=>sel==='#btn-roll'?targetEl:realQS3(sel);

// 状态：引导第 4 步（骰子屏的高亮位置——选一个实际存在的 sel）
S.onboarded=true;S.name='g';S.intentions=['read'];
S.tutorialDone=false;S.tutorialStep=4;
hideGuide();
positionGuide(TUT[4]);
// 此刻 target 在视口里
ok(els['guide-spot'].style.display==='block','初始定位：spot 落在 target 上');
ok(els['guide-spot'].style.left===(60-10)+'px'&&els['guide-spot'].style.top===(120-10)+'px','初始 spot 坐标 = target 坐标 - 10px 边距');
ok(els['guide-tip'].getAttribute('data-offscreen')===null,'目标在视口：tip 不标记 offscreen');

// 用户向上滑动 200px：target 的 top 变成 120-200=-80（滚出顶）
els['guide-spot'].setAttribute('data-before-scroll','1');
targetEl.getBoundingClientRect=()=>({...realRect,top:-80,bottom:-80+realRect.height});
fakeScreen._ls.scroll&&fakeScreen._ls.scroll();
// rAF：node 22 已内置 requestAnimationFrame；强制触发
if(typeof requestAnimationFrame==='function'){
  requestAnimationFrame(()=>requestAnimationFrame(()=>{}));
}
ok(els['guide-spot'].style.display==='none','目标滚出视口 → spot 自动隐藏');
ok(els['guide-tip'].getAttribute('data-offscreen')==='1','tip 标记 offscreen，居中提示用户滚回');
ok(els['guide-tip'].style.display==='block','tip 仍可见，提示用户滚回');

// 用户滚回来：target 回 120
targetEl.getBoundingClientRect=()=>({...realRect,top:120,bottom:120+realRect.height});
fakeScreen._ls.scroll&&fakeScreen._ls.scroll();
if(typeof requestAnimationFrame==='function'){
  requestAnimationFrame(()=>requestAnimationFrame(()=>{}));
}
ok(els['guide-spot'].style.display==='block','target 回视口 → spot 重新显示');
ok(els['guide-tip'].getAttribute('data-offscreen')===null,'tip 解除 offscreen 标记');

// 验证关闭引导会解绑监听
endTutorial();
ok(els['app'].classList.contains('guiding')===false,'endTutorial 后 guiding 类已移除');
// 再触发一次 scroll：守卫应阻止重定位
targetEl.getBoundingClientRect=()=>({...realRect,top:9999,bottom:9999+realRect.height});
fakeScreen._ls.scroll&&fakeScreen._ls.scroll();
if(typeof requestAnimationFrame==='function'){
  requestAnimationFrame(()=>requestAnimationFrame(()=>{}));
}
// spot 仍保持上一步的位置（spot 不会变 block，也不会变 none —— 仅在引导中才变）
ok(els['guide-tip'].getAttribute('data-offscreen')===null,'endTutorial 后滚动不再触发布局（已被守卫）');

global.document.querySelector=realQS3;
hideGuide();

// ──────────────────────────────────────────────
// H.6 Tip 智能选位：放在 target 对角象限的屏幕角落，永不挡 target 周围内容
// ──────────────────────────────────────────────
// H.6 setup：让 .app 的 offset 与生产一致（420×760）
els['app'].offsetWidth=420;
els['app'].offsetHeight=760;

console.log('--- H.6 Tip 智能选位（target 对角象限角落） ---');
function setupTarget(rect){
  const t={
    getBoundingClientRect:()=>({...rect,bottom:rect.top+rect.height,right:rect.left+rect.width}),
    scrollIntoView(){}
  };
  const realQS4=global.document.querySelector;
  global.document.querySelector=sel=>sel==='#btn-roll'?t:realQS4(sel);
  return t;
}
let r;

r=setupTarget({left:40,top:80,width:180,height:40});  // 左上象限 target
hideGuide();positionGuide(TUT[4]);
ok(els['guide-tip'].dataset.corner==='BR','target 在左上 → tip 在 BR 角（对角）');
ok(els['guide-tip'].style.left===(420-300-16)+'px','tip 紧贴屏幕右沿');
ok(els['guide-tip'].style.top===(760-170-88)+'px','tip 紧贴屏幕底部');

r=setupTarget({left:240,top:80,width:180,height:40});  // 右上象限 target
hideGuide();positionGuide(TUT[4]);
ok(els['guide-tip'].dataset.corner==='BL','target 在右上 → tip 在 BL 角（对角）');

r=setupTarget({left:40,top:600,width:180,height:40});  // 左下象限 target
hideGuide();positionGuide(TUT[4]);
ok(els['guide-tip'].dataset.corner==='TR','target 在左下 → tip 在 TR 角（对角）');

r=setupTarget({left:240,top:600,width:180,height:40});  // 右下象限 target
hideGuide();positionGuide(TUT[4]);
ok(els['guide-tip'].dataset.corner==='TL','target 在右下 → tip 在 TL 角（对角）');

// 边界兜底：超小视口 tip 不能越界
const W0=els['app'].offsetWidth, H0=els['app'].offsetHeight;
els['app'].offsetWidth=300;els['app'].offsetHeight=400;
r=setupTarget({left:40,top:80,width:180,height:40});
hideGuide();positionGuide(TUT[4]);
const tipStyle=els['guide-tip'].style;
ok(parseInt(tipStyle.left)>=16,'tip 左边界 ≥ 16（极小视口也兜底）');
ok(parseInt(tipStyle.top)>=16,'tip 上边界 ≥ 16');
els['app'].offsetWidth=W0;els['app'].offsetHeight=H0;

// 中央 target：tip 永远不会贴在 target 正上/正下方（老算法的痛点）
r=setupTarget({left:150,top:350,width:120,height:60});
hideGuide();positionGuide(TUT[4]);
const tipTopPx=parseInt(els['guide-tip'].style.top);
const targetTop=350,targetBottom=410;
const overlappingAbove=tipTopPx+170>=targetTop-30&&tipTopPx<=targetTop;
const overlappingBelow=tipTopPx+170>=targetBottom+30&&tipTopPx<=targetBottom+30;
ok(!(overlappingAbove||overlappingBelow),'中央 target：tip 不会紧贴 target 正上方 30px 或正下方 30px（老算法的痛点）');
ok(els['guide-tip'].dataset.corner&&/^(TL|TR|BL|BR)$/.test(els['guide-tip'].dataset.corner),'中央 target：仍落 4 角之一');

hideGuide();

// ──────────────────────────────────────────────
// 核心玩法（确保引导不影响）
// ──────────────────────────────────────────────
console.log('');
console.log('=== 核心玩法 ===');
S.tutorialDone=true;S.tutorialStep=0;S.onboarded=false;S.name='';S.intentions=[];S.tasks=[];
S.cycle=1;S.day=1;
S.cycleStats={done:0,rolled:0,byCat:{grow:0,habit:0,fate:0},streak:0,maxStreak:0,doneToday:0,daysLit:[]};
S.history=[];S.imprints=[];S.titles=[];S.cyclesCompleted=0;S.pendingReport=null;S.customPool=[];
hideGuide();

console.log('--- 1. 开场点火 ---');
els['ob-name'].value='tester';
els['ob-go'].click();
ok(S.onboarded===true,'onboarded 置位');
ok(S.name==='tester','名字留存');
ok(S.intentions.length>0,'意向默认值有效');

console.log('--- 2. 掷骰 → 接签 → 完成 → 入夜 ×21 ---');
for(let d=1;d<=21;d++){
  let guard=0;
  while(S.tasks.length<3&&guard++<5){
    els['btn-roll'].click();
    els['btn-accept'].click();
  }
  const ids=S.tasks.map(t=>t.id);
  ids.forEach(id=>completeTask(id));
  els['btn-night'].click();
  if(S.pendingReport)break;
}
ok(S.day===22||S.pendingReport,'到达第22日或月签已生成');
ok(!!S.pendingReport,'月签报告已生成');

console.log('--- 2.5 自拟签路径 ---');
const r1=S.pendingReport;
ok(!!r1&&typeof r1.rate==='number','循环1月签字段完整: 完成率'+r1.rate+'%');
els['btn-next'].click();
ok(S.cycle===2,'第2循环已开启');
const tasksBefore=S.tasks.length;
els['btn-roll'].click();
els['btn-custom'].click();
ok(S.tasks.length===tasksBefore,'自拟前 S.tasks 数量未变');
els['custom-n'].value='读《心流》序章';
els['custom-cat'].querySelector('button[data-c=habit]').classList.add('on');
els['custom-cat'].querySelector('button[data-c=grow]').classList.remove('on');
els['custom-d'].value='写下三个心流时刻';
els['custom-ok'].click();
ok(S.tasks.length===tasksBefore+1,'自拟签已入袖（+1）');
ok(S.tasks.some(t=>t.n==='读《心流》序章'&&t.cat==='habit'&&t.custom===true),'自拟签特征标记');
ok(S.customPool.some(t=>t.n==='读《心流》序章'&&t.cat==='habit'),'customPool 已记录');
ok(S.cycleStats.rolled===1,'自拟计入 rolled');
S.tasks.forEach(t=>completeTask(t.id));
els['btn-night'].click();

console.log('--- 3. 月签内容 ---');
ok(r1&&r1.done===21*3,'成签数: '+r1.done);
ok(r1&&r1.evals.length>=1&&r1.sugs.length>=1,'解读 '+r1.evals.length+' 段 / 建议 '+r1.sugs.length+' 条');
ok(r1&&r1.streak===21,'最长连燃=21');
ok(r1&&S.titles.includes('prairie'),'「燎原」称号已解锁');
ok(r1&&S.titles.includes('eternal'),'「长明」称号已解锁');
ok(r1&&S.titles.includes('torch'),'「执炬者」称号已解锁');
ok(r1&&S.imprints.length===r1.done+1,'印记数 = 循环1成签(63) + 自拟签(1) = '+S.imprints.length);

console.log('--- 4. 跨循环 ---');
ok(S.cycle===2&&S.tasks.length===0,'第2循环已开启');
ok(S.pendingReport===null,'月签已清空');
ok(S.imprints.length>0,'跨循环：印记保留 '+S.imprints.length+' 枚');

console.log('--- 5. 持久化 & 重载 ---');
save();
const snapshot=S.imprints.length;
global.localStorage.getItem=()=>JSON.stringify(S);
const S2=JSON.parse(global.localStorage.getItem());
ok(S2.imprints.length===snapshot,'localStorage 序列化往返一致');
ok(Math.abs(flameScale()-flameScale())<1e-9,'flameScale 稳定: '+flameScale().toFixed(2));

console.log('');
console.log(failed?('✗ '+failed+' 项失败'):'✓ 全部通过');
process.exit(failed?1:0);
